int deljiv_4(int x) {

    int ostatak = x % 4;

    if (ostatak == 0) {
        return 1;
    } else {
        return 0;
    }
}