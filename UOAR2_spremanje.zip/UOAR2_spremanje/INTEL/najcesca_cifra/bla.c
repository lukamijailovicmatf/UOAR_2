int najcesca_cifra(unsigned n) {

    // imacemo niz brojaca, po jedan brojac za svaku cifru
    int brojaci[10] = {};

    do {
        brojaci[n % 10]++;
        n = n / 10;
    } while (n != 0);

    int max_c;
    int max_bp = 0;

    for (int i = 0; i < 10; i++) {

        if (brojaci[i] > max_bp) {
            max_bp = brojaci[i];
            max_c = i;
        }
    }
    return max_c;
}