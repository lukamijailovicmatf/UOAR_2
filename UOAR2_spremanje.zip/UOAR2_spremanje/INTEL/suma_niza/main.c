#include <stdio.h>
#include <stdlib.h>

void error(const char* msg)
{
    fprintf(stderr, "Error; %s", msg);
    exit(EXIT_FAILURE);
}

extern int suma_niza(int* a, int n);

int main(int argc, char const *argv[])
{
    int n;
    int *a;
    scanf("%d", &n);

    if((a = malloc(n * sizeof(int))) == NULL) 
        error("neuspela alokacija");

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    

    int suma = suma_niza(a, n);
    printf("%d\n", suma);

    free(a);
    return 0;
}