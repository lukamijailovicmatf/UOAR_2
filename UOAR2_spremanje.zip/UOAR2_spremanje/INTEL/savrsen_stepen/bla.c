int savrsen_stepen(unsigned n, unsigned *pm, unsigned *pk) {

    for (unsigned m = 2; m < n; m++) {
        // racunamo stepen od m, na pocetku je m^2
        unsigned stepen = m * m;
        unsigned k = 2;

        while (stepen <= n) {
            if (stepen == n) {
                *pm = m;
                *pk = k
                return 1;
            }
            // u suprotnom stepen je i dalje manji ali nije jednak
            // tako da treba proveriti sledeci stepen da li nam odgovara
            stepen = stepen * m;
            k++;
        }
    }
    return 0;
}