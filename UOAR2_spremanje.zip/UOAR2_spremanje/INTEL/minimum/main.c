#include <stdio.h>

extern int min(int x, int y);

int main(){

    int x, y;
    scanf("%d %d", &x, &y);
    printf("min(%d, %d) = %d\n", x, y, min(x, y));

    return 0;
}