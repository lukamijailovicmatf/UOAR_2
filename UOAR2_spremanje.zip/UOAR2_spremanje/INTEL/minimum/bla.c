int min(int x, int y) {

    int minimum;

    if (x < y) {
        minimum = x;
    } else {
        minimum = y;
    }
    return minimum;
}