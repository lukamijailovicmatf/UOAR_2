int saberi(int x, int y) {
    return x+y;
}