void obrni(int* a, int n) {

    int *levi = &a[0];
    int *desni = &a[n-1];

    while (levi < desni) {
        int pom = *levi; // u pom smesti ono sto je na adresi levi
        *levi = *desni; // u levi smesti vrednost iz desnog
        *desni = pom; // u desni smesti vrednost pom
        levi++;
        desni--;
    }
}

// druga verzija funkcije za obrtanje niza
void obrni(int* a, int n) {

    int levi = 0; // pocetak niza
    int desni = n-1; // kraj niza

    while (levi < desni) {
        int pom = a[levi];
        a[levi] = a[desni];
        a[desni] = pom;
        levi++;
        desni--;
    }
}