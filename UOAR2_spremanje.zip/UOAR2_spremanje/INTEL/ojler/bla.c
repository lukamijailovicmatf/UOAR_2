unsigned ojler(unsigned n) {

    unsigned broj_up = 0;
    for (unsigned i = 1; i < n; i++) {
        // ako je nzd dva broja 1 onda su prosti
        if (nzd(i,n) == 1) {
            broj_up++;
        }
    }
    return broj_up;
}