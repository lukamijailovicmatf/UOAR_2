#include <stdio.h>

extern int oduzmi(int x, int y);

int main(){

    printf("Unesite dva cela broja: ");
    int x, y;
    scanf("%d %d", &x, &y);
    int razlika = oduzmi(x, y);
    printf("%d - %d = %d\n", x, y, razlika);

    return 0;
}