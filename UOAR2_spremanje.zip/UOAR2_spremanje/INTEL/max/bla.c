int max(int x, int y) {

    int maksimum;

    if (x > y) {
        maksimum = x;
    } else {
        maksimum = y;
    }
    return maksimum;
}