void zameni(int *px, int *py) {

    int vx = *px; // vrednost x je sadrzaj sa adrese px
    int vy = *py; // vrednost y je sadrzaj sa adrese py
    *px = vy; // sadrzaj sa adrese px neka bude vrednost y
    *py = vx; // sadrzaj sa adrese py neka bude vrednost x
}

// ovaj kod ne moze u asembleru
void zameni(int *px, int *py) {

    int pom = *px;
    *px = *py; // PROBLEM!!!
    *py = pom;
}