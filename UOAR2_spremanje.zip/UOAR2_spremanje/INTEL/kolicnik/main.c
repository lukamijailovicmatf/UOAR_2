#include <stdio.h>

extern void kolicnik(int x, int y, int *k, int *o);


int main(int argc, char const *argv[])
{
    int x, y;
    int k, o;
    scanf("%d%d", &x, &y);
    kolicnik(x, y, &k, &o);
    printf("%d = %d * %d + %d\n", x, y, k, o);
    return 0;
}