extern void kolicnik(int x, int y, int *k, int *o) {

    *k = x / y; // sadrzaj na adresi kolicnika
    *o = x % y; // sadrzaj na adresi ostatka
}