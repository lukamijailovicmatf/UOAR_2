unsigned suma_parnih(unsigned n) {

    unsigned trenutna_suma = 0;

    for (unsigned i = 1; i <= n; i++) {
        if (i % 2 == 0) {
            trenutna_suma = trenutna_suma + i;
        }
    }
    return trenutna_suma;
}

unsigned suma_parnih(unsigned n) {

    unsigned trenutna_suma = 0;

    for (unsigned i = 2; i <= n; i+=2) {
        trenutna_suma = trenutna_suma + i;
    }
    return trenutna_suma;
}