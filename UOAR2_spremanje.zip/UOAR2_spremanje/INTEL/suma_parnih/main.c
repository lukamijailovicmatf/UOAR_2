#include <stdio.h>

extern unsigned suma_parnih(unsigned);

int main(){

    unsigned n;
    scanf("%u", &n);

    printf("%d\n", suma_parnih(n));

    return 0;
}