int suma(int* a, int n) {

    int s = 0;
    for (int i = 0; i < n; i++)
        s += a[i];

    return s;
}

int suma(int* a, int n) {

    int s = 0;
    a--;

    while (n > 0) {
        a++;
        s += *a;
        n--;
    }
    
    return s;
}