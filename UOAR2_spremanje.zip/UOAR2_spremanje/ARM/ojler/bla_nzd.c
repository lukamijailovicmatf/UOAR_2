// nama pripadaju registri od r0 - r3 tj. njih mozemo da menjamo do mile volje
// registre od r4 - r10 moramo da sacuvamo njihove vrednosti
// ako pozivamo neku drugu funkciju registri od r4 - r10 ce ostati nepromenjeni
// dok ce se registri od r0 - r3 potencijalno promeniti
// svaki put kada pozivamo neku funkciju registre od r4 - r10 koristimo za
// sto vise vrednosti mozemo
// u ovom slucaju imamo funkciju deljenja zato cemo r0 i r1 da zapamtimo
// na primer u registrima r4 i r5 da ne bismo razmisljali o steku
// posto cemo koristiti registre r4 i r5 njih odmah na pocetku pamtimo
// na steku i skidamo ih sa steka

// iterativna verzija
unsigned nzd(unsigned x, unsigned y) {

    while (y != 0) {
        unsigned tmp = x % y;
        x = y;
        y = tmp;
    }
    return x;
}

// rekurzivna verzija
unsigned nzd(unsigned x, unsigned y) {

    if (y == 0)
        return x;

    return nzd(y, x % y);
}