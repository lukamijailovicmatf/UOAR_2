int max_element(int* a, int n) {

    int max = a[0];

    for (int i = 1; i < n; i++)
        if (max < a[i])
            max = a[i];

    return max;
}

int max_element(int* a, int n) {

    int max = a[0];
    a++;

    while (n > 1) {
        
        int tmp = *a;
        a++;

        if (tmp > max)
            max = tmp;

        n--;
    }
    return max;
}