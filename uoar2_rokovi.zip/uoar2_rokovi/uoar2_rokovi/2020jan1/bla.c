unsigned stepen(unsigned n) {

    unsigned proizvod = 1;
    
    while(proizvod <= n) {
        proizvod *= 2;
    }
    return proizvod;
}

// drugi i treći zad: prost i izbacivanje prostih iz niza
