#include <stdio.h>

int prost(int n);

int main(){

    int n;
    scanf("%d", &n);
    printf("%d\n", prost(n));
}