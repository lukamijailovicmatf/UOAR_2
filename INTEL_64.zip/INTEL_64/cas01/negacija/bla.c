unsigned negacija(unsigned x){

    return ~x;
}